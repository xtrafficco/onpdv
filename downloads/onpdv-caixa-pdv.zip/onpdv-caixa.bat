@echo off
setlocal
cd /d "%~dp0"

set "ONPDV_NODE=%~dp0runtime\node.exe"
if not exist "%ONPDV_NODE%" (
  where node >nul 2>nul
  if not errorlevel 1 set "ONPDV_NODE=node"
)

if not defined ONPDV_NODE (
  echo O Node.js nao foi encontrado. Instale o Node.js para iniciar o ONPDV local.
  pause
  exit /b 1
)

"%ONPDV_NODE%" "%~dp0onpdv-caixa.mjs"
if errorlevel 1 (
  echo Nao foi possivel iniciar o ONPDV Caixa.
  pause
  exit /b 1
)

endlocal
