#!/usr/bin/env node
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const bridgeVersion = 'native-print-v1';

function serverProbe(port) {
  return new Promise((resolve) => {
    const request = http.get(`http://127.0.0.1:${port}/api/version`, (response) => {
      const chunks = [];
      response.on('data', chunk => chunks.push(chunk));
      response.on('end', () => {
        try {
          const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          resolve(body.version === bridgeVersion ? 'ready' : 'occupied');
        } catch {
          resolve('occupied');
        }
      });
    });
    request.setTimeout(700, () => {
      request.destroy();
      resolve('occupied');
    });
    request.on('error', error => resolve(error.code === 'ECONNREFUSED' ? 'free' : 'occupied'));
  });
}

async function startLocalServer() {
  for (let port = 4173; port <= 4192; port++) {
    const state = await serverProbe(port);
    if (state === 'ready') return port;
    if (state !== 'free') continue;
    const server = spawn(process.execPath, [path.join(root, 'serve-local.mjs')], {
      cwd: root,
      env: { ...process.env, PORT: String(port) },
      detached: true,
      stdio: 'ignore',
      windowsHide: true
    });
    server.unref();
    for (let attempt = 0; attempt < 40; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 100));
      if (await serverProbe(port) === 'ready') return port;
    }
  }
  throw new Error('O servidor local do ONPDV não iniciou em nenhuma porta disponível.');
}

function printerIsReady(port) {
  return new Promise((resolve) => {
    const request = http.get(`http://127.0.0.1:${port}/api/print/status`, (response) => {
      const chunks = [];
      response.on('data', chunk => chunks.push(chunk));
      response.on('end', () => {
        try {
          const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          resolve(body.ok ? body.printer : '');
        } catch {
          resolve('');
        }
      });
    });
    request.setTimeout(5000, () => {
      request.destroy();
      resolve('');
    });
    request.on('error', () => resolve(''));
  });
}

function configureDensityOnce(printer) {
  const localRoot = path.join(process.env.LOCALAPPDATA || root, 'ONPDV');
  const marker = path.join(localRoot, 'print-density-120-v1.ok');
  if (fs.existsSync(marker)) return Promise.resolve();
  // A densidade via GS ( E e um comando exclusivo Epson. Em impressoras de outras
  // marcas (Bematech etc.) pulamos este passo para nao enviar bytes indevidos.
  if (!/epson|tm-/i.test(printer || '')) {
    try { fs.mkdirSync(localRoot, { recursive: true }); fs.writeFileSync(marker, 'skipped-non-epson', 'utf8'); } catch { /* best-effort */ }
    return Promise.resolve();
  }
  return new Promise((resolve, reject) => {
    const shell = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const child = spawn(shell, [
      '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
      '-File', path.join(root, 'print-raw.ps1'),
      '-PrinterName', printer,
      '-ConfigureDensity'
    ], { cwd: root, windowsHide: true, stdio: 'ignore' });
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error('A configuração de intensidade da impressora não respondeu.'));
    }, 15000);
    child.on('error', error => {
      clearTimeout(timer);
      reject(error);
    });
    child.on('exit', code => {
      clearTimeout(timer);
      if (code !== 0) {
        reject(new Error('Não foi possível configurar a intensidade da impressora.'));
        return;
      }
      fs.mkdirSync(localRoot, { recursive: true });
      fs.writeFileSync(marker, new Date().toISOString(), 'utf8');
      resolve();
    });
  });
}

const port = await startLocalServer();
const printer = await printerIsReady(port);
if (!printer) {
  throw new Error('A impressora padrão do Windows não está disponível. Verifique a fila antes de abrir o ONPDV.');
}
await configureDensityOnce(printer);
const url = `http://127.0.0.1:${port}/?onpdv-kiosk=1`;

const programFiles = process.env.ProgramFiles || 'C:\\Program Files';
const programFilesX86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
const candidates = [
  path.join(programFiles, 'Google', 'Chrome', 'Application', 'chrome.exe'),
  path.join(programFilesX86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
  path.join(programFilesX86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
  path.join(programFiles, 'Microsoft', 'Edge', 'Application', 'msedge.exe')
];
const browser = candidates.find(candidate => fs.existsSync(candidate));
if (!browser) throw new Error('Chrome ou Edge não encontrado.');

const profile = path.join(process.env.LOCALAPPDATA || root, 'ONPDV', 'browser-profile-native-print');
const app = spawn(browser, [
  '--kiosk-printing',
  '--start-fullscreen',
  '--no-first-run',
  '--no-default-browser-check',
  '--disable-session-crashed-bubble',
  `--user-data-dir=${profile}`,
  `--app=${url}`
], {
  cwd: root,
  detached: true,
  stdio: 'ignore',
  windowsHide: true
});
app.unref();
