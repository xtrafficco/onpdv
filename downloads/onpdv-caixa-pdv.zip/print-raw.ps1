param(
  [string]$PrinterName = '',
  [string]$QrData = '',
  [switch]$StatusOnly,
  [switch]$ConfigureDensity
)

$ErrorActionPreference = 'Stop'

if (-not ('OnpdvRawPrinter' -as [type])) {
  Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;

public static class OnpdvRawPrinter {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct DOC_INFO_1 {
    [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
    [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
    [MarshalAs(UnmanagedType.LPWStr)] public string pDataType;
  }

  [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Unicode)]
  public static extern bool OpenPrinter(string printerName, out IntPtr printer, IntPtr defaults);

  [DllImport("winspool.drv", SetLastError = true)]
  public static extern bool ClosePrinter(IntPtr printer);

  [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Unicode, EntryPoint = "StartDocPrinterW")]
  public static extern int StartDocPrinter(IntPtr printer, int level, ref DOC_INFO_1 docInfo);

  [DllImport("winspool.drv", SetLastError = true)]
  public static extern bool EndDocPrinter(IntPtr printer);

  [DllImport("winspool.drv", SetLastError = true)]
  public static extern bool StartPagePrinter(IntPtr printer);

  [DllImport("winspool.drv", SetLastError = true)]
  public static extern bool EndPagePrinter(IntPtr printer);

  [DllImport("winspool.drv", SetLastError = true)]
  public static extern bool WritePrinter(IntPtr printer, byte[] bytes, int count, out int written);

  [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Unicode)]
  public static extern bool GetDefaultPrinter(StringBuilder buffer, ref int size);

  public static void ThrowLastError(string operation) {
    throw new Win32Exception(Marshal.GetLastWin32Error(), operation);
  }
}
'@
}

function Get-OnpdvDefaultPrinter {
  $size = 0
  [void][OnpdvRawPrinter]::GetDefaultPrinter($null, [ref]$size)
  if ($size -le 1) { [OnpdvRawPrinter]::ThrowLastError('Nenhuma impressora padrão configurada') }
  $buffer = New-Object System.Text.StringBuilder($size)
  if (-not [OnpdvRawPrinter]::GetDefaultPrinter($buffer, [ref]$size)) {
    [OnpdvRawPrinter]::ThrowLastError('Não foi possível localizar a impressora padrão')
  }
  return $buffer.ToString()
}

if ([string]::IsNullOrWhiteSpace($PrinterName)) {
  $PrinterName = Get-OnpdvDefaultPrinter
}

$handle = [IntPtr]::Zero
if (-not [OnpdvRawPrinter]::OpenPrinter($PrinterName, [ref]$handle, [IntPtr]::Zero)) {
  [OnpdvRawPrinter]::ThrowLastError("Não foi possível abrir a impressora $PrinterName")
}

if ($StatusOnly) {
  [void][OnpdvRawPrinter]::ClosePrinter($handle)
  [Console]::Out.Write($PrinterName)
  exit 0
}

if ($ConfigureDensity) {
  # GS ( E: entra no modo de usuário, define densidade +20% (valor 2) e sai
  # realizando o reset de software exigido pela Epson. O launcher chama isto
  # somente uma vez e grava um marcador para não desgastar a memória NV.
  $payload = [byte[]](
    0x1D, 0x28, 0x45, 0x03, 0x00, 0x01, 0x49, 0x4E,
    0x1D, 0x28, 0x45, 0x04, 0x00, 0x05, 0x05, 0x02, 0x00,
    0x1D, 0x28, 0x45, 0x04, 0x00, 0x02, 0x4F, 0x55, 0x54
  )
  $configDoc = New-Object OnpdvRawPrinter+DOC_INFO_1
  $configDoc.pDocName = 'ONPDV - Configurar densidade 120%'
  $configDoc.pOutputFile = $null
  $configDoc.pDataType = 'RAW'
  $configStarted = $false
  $configPage = $false
  try {
    if ([OnpdvRawPrinter]::StartDocPrinter($handle, 1, [ref]$configDoc) -le 0) {
      [OnpdvRawPrinter]::ThrowLastError('Não foi possível iniciar a configuração de densidade')
    }
    $configStarted = $true
    if (-not [OnpdvRawPrinter]::StartPagePrinter($handle)) {
      [OnpdvRawPrinter]::ThrowLastError('Não foi possível iniciar a configuração da impressora')
    }
    $configPage = $true
    $configWritten = 0
    if (-not [OnpdvRawPrinter]::WritePrinter($handle, $payload, $payload.Length, [ref]$configWritten)) {
      [OnpdvRawPrinter]::ThrowLastError('Falha ao configurar a densidade')
    }
    if ($configWritten -ne $payload.Length) { throw 'Configuração de densidade incompleta' }
  }
  finally {
    if ($configPage) { [void][OnpdvRawPrinter]::EndPagePrinter($handle) }
    if ($configStarted) { [void][OnpdvRawPrinter]::EndDocPrinter($handle) }
    if ($handle -ne [IntPtr]::Zero) { [void][OnpdvRawPrinter]::ClosePrinter($handle) }
  }
  [Console]::Out.Write($PrinterName)
  exit 0
}

$reader = $null
$documentStarted = $false
$pageStarted = $false
try {
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  $reader = New-Object System.IO.StreamReader([Console]::OpenStandardInput(), $utf8)
  $text = $reader.ReadToEnd()
  if ([string]::IsNullOrWhiteSpace($text)) { throw 'Documento de impressão vazio' }

  # PC860 preserva os caracteres portugueses na EPSON TM-T20.
  $encoding = [System.Text.Encoding]::GetEncoding(860)
  $bytes = New-Object 'System.Collections.Generic.List[byte]'
  # Inicializa, seleciona PC860, aumenta a altura dos caracteres e combina
  # emphasized + double-strike. Na TM-T20 o double-strike reforça cada caractere.
  $bytes.AddRange([byte[]](
    0x1B, 0x40,
    0x1B, 0x74, 0x03,
    0x1D, 0x21, 0x01,
    0x1B, 0x45, 0x01,
    0x1B, 0x47, 0x01
  ))
  $bytes.AddRange([byte[]]$encoding.GetBytes($text.Replace("`r`n", "`n").Replace("`r", "`n")))
  $bytes.AddRange([byte[]](
    0x1B, 0x45, 0x00,
    0x1B, 0x47, 0x00,
    0x1D, 0x21, 0x00,
    0x0A, 0x0A
  ))

  if (-not [string]::IsNullOrWhiteSpace($QrData)) {
    $qr = [System.Text.Encoding]::ASCII.GetBytes($QrData)
    $storeLength = $qr.Length + 3
    $pL = [byte]($storeLength % 256)
    $pH = [byte][Math]::Floor($storeLength / 256)
    $bytes.AddRange([byte[]](0x1B, 0x61, 0x01))
    $bytes.AddRange([byte[]](0x1D, 0x28, 0x6B, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00))
    $bytes.AddRange([byte[]](0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43, 0x05))
    $bytes.AddRange([byte[]](0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x45, 0x30))
    $bytes.AddRange([byte[]](0x1D, 0x28, 0x6B, $pL, $pH, 0x31, 0x50, 0x30))
    $bytes.AddRange([byte[]]$qr)
    $bytes.AddRange([byte[]](0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x51, 0x30))
    $bytes.AddRange([byte[]](0x1B, 0x61, 0x00, 0x0A))
  }

  $bytes.AddRange([byte[]](0x0A, 0x0A, 0x0A, 0x1D, 0x56, 0x42, 0x00))
  $payload = $bytes.ToArray()

  $doc = New-Object OnpdvRawPrinter+DOC_INFO_1
  $doc.pDocName = 'ONPDV'
  $doc.pOutputFile = $null
  $doc.pDataType = 'RAW'
  if ([OnpdvRawPrinter]::StartDocPrinter($handle, 1, [ref]$doc) -le 0) {
    [OnpdvRawPrinter]::ThrowLastError('Não foi possível iniciar o documento')
  }
  $documentStarted = $true
  if (-not [OnpdvRawPrinter]::StartPagePrinter($handle)) {
    [OnpdvRawPrinter]::ThrowLastError('Não foi possível iniciar a página')
  }
  $pageStarted = $true
  $written = 0
  if (-not [OnpdvRawPrinter]::WritePrinter($handle, $payload, $payload.Length, [ref]$written)) {
    [OnpdvRawPrinter]::ThrowLastError('Falha ao enviar dados para a impressora')
  }
  if ($written -ne $payload.Length) {
    throw "Impressão incompleta: $written de $($payload.Length) bytes"
  }
}
finally {
  if ($reader) { $reader.Dispose() }
  if ($pageStarted) { [void][OnpdvRawPrinter]::EndPagePrinter($handle) }
  if ($documentStarted) { [void][OnpdvRawPrinter]::EndDocPrinter($handle) }
  if ($handle -ne [IntPtr]::Zero) { [void][OnpdvRawPrinter]::ClosePrinter($handle) }
}

[Console]::Out.Write($PrinterName)
