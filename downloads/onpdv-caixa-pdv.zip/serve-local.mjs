#!/usr/bin/env node
import { spawn } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const port = Number(process.env.PORT || 4173);
const bridgeVersion = 'native-print-v1';
const printScript = path.join(root, 'print-raw.ps1');
const types = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.png': 'image/png',
  '.webmanifest': 'application/manifest+json; charset=utf-8'
};

function json(response, status, value) {
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-ONPDV-Local': bridgeVersion
  });
  response.end(JSON.stringify(value));
}

function runPrintBridge({ printer = '', qr = '', text = '', statusOnly = false }) {
  return new Promise((resolve, reject) => {
    const shell = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const args = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', printScript];
    if (printer) args.push('-PrinterName', printer);
    if (qr) args.push('-QrData', qr);
    if (statusOnly) args.push('-StatusOnly');
    const child = spawn(shell, args, { cwd: root, windowsHide: true });
    let stdout = '', stderr = '', settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      child.kill();
      reject(new Error('A fila de impressão não respondeu em 20 segundos.'));
    }, 20000);
    child.stdout.on('data', chunk => { if (stdout.length < 4096) stdout += chunk.toString('utf8'); });
    child.stderr.on('data', chunk => { if (stderr.length < 8192) stderr += chunk.toString('utf8'); });
    child.on('error', error => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(error);
    });
    child.on('exit', code => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (code === 0) resolve(stdout.trim());
      else reject(new Error((stderr || stdout || `Falha de impressão (${code})`).trim()));
    });
    if (statusOnly) child.stdin.end();
    else child.stdin.end(text, 'utf8');
  });
}

function readJson(request, maxBytes = 131072) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    request.on('data', chunk => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(new Error('Documento de impressão muito grande.'));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(new Error('Documento de impressão inválido.')); }
    });
    request.on('error', reject);
  });
}

http.createServer(async (request, response) => {
  const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
  if (pathname === '/api/version') {
    json(response, 200, { ok: true, version: bridgeVersion });
    return;
  }
  if (pathname === '/api/print/status') {
    try {
      const printer = await runPrintBridge({ statusOnly: true });
      json(response, 200, { ok: true, printer, version: bridgeVersion });
    } catch (error) {
      json(response, 503, { ok: false, error: error.message });
    }
    return;
  }
  if (pathname === '/api/print') {
    if (request.method !== 'POST' || request.headers['x-onpdv-print'] !== '1') {
      json(response, 403, { ok: false, error: 'Requisição de impressão não autorizada.' });
      return;
    }
    try {
      const body = await readJson(request);
      const text = typeof body.text === 'string' ? body.text : '';
      const printer = typeof body.printer === 'string' ? body.printer.trim().slice(0, 200) : '';
      const qr = typeof body.qr === 'string' ? body.qr.trim().slice(0, 1000) : '';
      if (!text.trim() || text.length > 60000) throw new Error('Documento de impressão vazio ou muito grande.');
      const usedPrinter = await runPrintBridge({ printer, qr, text });
      json(response, 200, { ok: true, printer: usedPrinter });
    } catch (error) {
      json(response, 500, { ok: false, error: error.message });
    }
    return;
  }

  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const file = path.resolve(root, relative);
  if (!file.startsWith(`${root}${path.sep}`) && file !== root) {
    response.writeHead(403).end('Forbidden');
    return;
  }
  fs.readFile(file, (error, body) => {
    if (error) {
      response.writeHead(error.code === 'ENOENT' ? 404 : 500).end('Not found');
      return;
    }
    response.writeHead(200, {
      'Content-Type': types[path.extname(file)] || 'application/octet-stream',
      'Cache-Control': 'no-store',
      'X-ONPDV-Local': bridgeVersion
    });
    response.end(request.method === 'HEAD' ? undefined : body);
  });
}).listen(port, '127.0.0.1', () => {
  console.log(`ONPDV local em http://127.0.0.1:${port}`);
});
